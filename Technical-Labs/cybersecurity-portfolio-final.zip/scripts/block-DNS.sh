#!/bin/bash
# DNS sinkhole script: map bad domains to 127.0.0.1 in /etc/hosts.
