# PowerShell: Enumerate AD user details and memberships.
