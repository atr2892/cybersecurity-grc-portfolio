# PowerShell: Enumerate domain users.
