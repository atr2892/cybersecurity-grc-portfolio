#!/bin/bash
# Nmap analysis script
# Scans a CIDR and lists hosts with specified open port(s).
