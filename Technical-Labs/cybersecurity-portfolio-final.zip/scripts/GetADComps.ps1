# PowerShell: Enumerate domain computers.
