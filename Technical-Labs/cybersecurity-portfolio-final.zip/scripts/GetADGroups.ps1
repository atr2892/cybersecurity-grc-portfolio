# PowerShell: Enumerate domain groups.
