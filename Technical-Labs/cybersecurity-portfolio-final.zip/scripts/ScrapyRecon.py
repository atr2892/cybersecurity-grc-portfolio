# Example Scrapy spider for recon on target site (lab only).
