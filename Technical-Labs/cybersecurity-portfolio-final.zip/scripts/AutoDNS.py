# Example Python script for automated DNS/Scapy queries.
