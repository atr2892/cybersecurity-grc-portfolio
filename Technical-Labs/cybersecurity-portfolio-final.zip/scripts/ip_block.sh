#!/bin/bash
# Firewall IP block script: apply DROP rules from threat-feed CIDRs.
